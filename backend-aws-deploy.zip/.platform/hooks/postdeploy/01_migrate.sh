#!/bin/bash
cd /var/app/current
mkdir -p storage
chmod 755 storage
